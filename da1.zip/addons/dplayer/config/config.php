<?php
$player=array (
  'ads' => 
  array (
    'status' => '0',
    'vip' => '0',
    'group' => '1',
  ),
  'pre' => 
  array (
    'status' => '1',
    'url' => 'http://www.kgwv.com/',
  ),
  'logo' => 
  array (
    'status' => '1',
    'url' => 'http://xbys.cc/upload/addon/20200202-1/200f23dea2833d607625a3841b60de87.png',
  ),
  'copyright' => 
  array (
    'status' => '0',
    'content' => '小白影视',
    'url' => 'http://www.xbys.cc/',
  ),
  'dp' => 
  array (
    'auto' => '1',
    'last' => '1',
    'next' => '1',
    'h5' => NULL,
  ),
);
$pre=array (
  'ads' => 
  array (
    'status' => '0',
    'time' => '3',
    'button' => '0',
    'auth' => '0',
    'group' => '3',
  ),
  'pic' => 
  array (
    'status' => '0',
    'img' => '',
    'link' => '',
    'width' => '',
    'height' => '',
  ),
  'vod' => 
  array (
    'status' => '0',
    'url' => '',
    'link' => '',
  ),
);
$pause=array (
  'status' => '0',
  'pic' => 'http://xbys.cc/upload/addon/20200202-1/45377662dbbf9f18d55fd33578570bef.png',
  'width' => '500',
  'height' => '500',
  'link' => 'http://xbys.cc/',
);
