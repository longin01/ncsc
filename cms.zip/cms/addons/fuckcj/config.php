<?php
return array (
  0 => 
  array (
    'name' => 'string',
    'title' => '官方地址',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'https://www.fuckcj.xyz/',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
);