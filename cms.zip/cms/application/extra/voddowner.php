<?php
return array (
  'xunlei' => 
  array (
    'status' => '1',
    'from' => 'xunlei',
    'show' => 'xunlei下载',
    'des' => 'des提示信息',
    'ps' => '0',
    'parse' => '',
    'sort' => '90',
    'tip' => 'tip提示信息',
    'id' => 'xunlei',
  ),
    'http' =>
        array (
            'status' => '1',
            'from' => 'http',
            'show' => 'http下载',
            'des' => 'des提示信息',
            'ps' => '0',
            'parse' => '',
            'sort' => '90',
            'tip' => 'tip提示信息',
            'id' => 'http',
        ),
);
?>