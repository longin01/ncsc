<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:37:"template/JSUIZ2/html/index/index.html";i:1652089818;s:58:"/home/wwwroot/cms/template/JSUIZ2/html/public/include.html";i:1652089818;s:55:"/home/wwwroot/cms/template/JSUIZ2/html/public/head.html";i:1652089818;s:55:"/home/wwwroot/cms/template/JSUIZ2/html/public/foot.html";i:1652089818;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="Content-type" name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" />
		<title><?php echo $maccms['site_name']; ?></title>
		<meta name="keywords" content="<?php echo $maccms['site_keywords']; ?>" />
		<meta name="description" content="<?php echo $maccms['site_description']; ?>" />
		<link rel="stylesheet" href="<?php echo $maccms['path']; ?>static/jsui/css/style.css" />
<script src="<?php echo $maccms['path']; ?>static/jsui/js/jquery.min.js"></script>
<script>var maccms={"path":"","mid":"<?php echo $maccms['mid']; ?>","aid":"<?php echo $maccms['aid']; ?>","url":"<?php echo $maccms['site_url']; ?>","wapurl":"<?php echo $maccms['site_wapurl']; ?>","mob_status":"<?php echo $maccms['mob_status']; ?>"};</script>

	</head>

	<body>
			<div id="nav" class="nav-wrap">
			<div class="area">
				<dl>
					<dt><span class="logo"><a href="/"><?php echo $maccms['site_url']; ?></a></span></dt>
					<dd class="mt">
						<a href="/"><i class="icon-home"></i></a>
					</dd>
					<dd>
						<a href="<?php echo $GLOBALS['config']['extra']['appdown']; ?>" target="_blank"><i class="icon-app"></i><span class="pc">APP下载</span></a>
					</dd>
				</dl>
			</div>
		</div>
		<div id="topBox"></div>
		
		<div id="menu" class="menu-wrap">
			<div class="area">
				<?php $__TAG__ = '{"ids":"1,2,3,4","order":"asc","by":"sort","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?> 
				<dl class="first">
					<dt><a href="#"><?php echo $vo['type_name']; ?></a></dt>
					<?php $__TAG__ = '{"parent":"'.$vo['type_id'].'","order":"asc","by":"sort","id":"vo2","key":"key2"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key2 = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo2): $mod = ($key2 % 2 );++$key2;?> 
					<dd>
						<a href="<?php echo mac_url_type($vo2); ?>"><?php echo $vo2['type_name']; ?></a>
					</dd>
					<?php endforeach; endif; else: echo "" ;endif; ?>     
				</dl>
				<?php endforeach; endif; else: echo "" ;endif; ?>
				<div id="subMenuBox"></div>
			</div>
		</div>
		<div id="midBox"></div>
		<?php $__TAG__ = '{"ids":"1,2","order":"asc","by":"sort","id":"vo","key":"key"}';$__LIST__ = model("Type")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
		<div class="mod">
			<div class="area">
				<div class="mod-title">
					<h3><a href="#"><?php echo $vo['type_name']; ?></a></h3></div>
				<div class="mod-row col5 clearfix">
				<?php $__TAG__ = '{"num":"20","type":"'.$vo['type_id'].'","order":"desc","by":"time","id":"vo","key":"key"}';$__LIST__ = model("Vod")->listCacheData($__TAG__); if(is_array($__LIST__['list']) || $__LIST__['list'] instanceof \think\Collection || $__LIST__['list'] instanceof \think\Paginator): $key = 0; $__LIST__ = $__LIST__['list'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($key % 2 );++$key;?>
					<dl>
						<dt><a href="<?php echo mac_url_vod_play($vo); ?>" title="<?php echo $vo['vod_name']; ?>" target="_blank"><img src="<?php echo $maccms['path']; ?>static/jsui/images/empty.jpg"><img class="nature" src="<?php echo $maccms['path']; ?>static/jsui/images/sprite.gif" data-original="<?php echo mac_url_img($vo['vod_pic']); ?>" alt="<?php echo $vo['vod_name']; ?>" /><i><?php echo date('Y年m月d日',$vo['vod_time']); ?></i></a></dt>
						<dd>
							<a href="<?php echo mac_url_vod_play($vo); ?>" target="_blank">
								<h2><?php echo $vo['vod_name']; ?></h2></a>
						</dd>
					</dl>
				<?php endforeach; endif; else: echo "" ;endif; ?>
			

				</div>
			</div>
		</div>
		<?php endforeach; endif; else: echo "" ;endif; ?>	
		<div id="btmBox"></div>
		<script src="<?php echo $maccms['path']; ?>static/jsui/js/common.js"></script>
		<script src="<?php echo $maccms['path']; ?>static/jsui/js/base.js"></script>
		<div style="display:none;"><?php echo $maccms['site_tj']; ?></div>
	</body>

</html>