<?php
/**
商务服务中心 版权所有
**/
namespace addons\caiji;use think\Addons;class caiji extends Addons{public function install(){return true;}public function uninstall(){return true;}}