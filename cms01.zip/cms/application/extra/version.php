<?php
return array (
    'name' => '苹果CMS',
    'copyright' => 'MacCMS.COM',
    'url' => 'http://www.maccms.com/',
    'code' => '2019.03.06.1617',
    'license' => '免费版',
);
?>