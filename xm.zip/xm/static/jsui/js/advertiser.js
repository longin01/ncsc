
var advertiser = "1";